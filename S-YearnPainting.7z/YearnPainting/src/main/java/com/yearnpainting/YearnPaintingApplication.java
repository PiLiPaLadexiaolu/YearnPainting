package com.yearnpainting;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.servlet.ServletComponentScan;

/**
 * 
 * @author KuMan
 *
 */
@SpringBootApplication
@ServletComponentScan
public class YearnPaintingApplication {

	public static void main(String[] args) {
		SpringApplication.run(YearnPaintingApplication.class, args);
	}

}
