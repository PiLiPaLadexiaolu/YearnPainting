package com.yearnpainting.test.controller;

import java.util.List;
import javax.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.yearnpainting.system.annotatin.CheckToken;
import com.yearnpainting.system.annotatin.PassToken;
import com.yearnpainting.system.utils.JWTUtil;
import com.yearnpainting.test.entity.Test;
import com.yearnpainting.test.mapper.TestMapper;
import com.yearnpainting.user.entity.User;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("test")
public class DataInterfaceController {
	
	@Autowired
	TestMapper testMapper;
	
	@GetMapping("hello")
	public String Test0001(HttpServletRequest request) {
		List<Test> list= testMapper.getAll();
		for (Test test : list) {
			System.out.println(test.getTestOne());
			log.info("数据");
		}
		return "Hello";
	}
	
	@GetMapping("token")
	@CheckToken
	public String Test0002(HttpServletRequest request) {
		List<Test> list= testMapper.getAll();
		for (Test test : list) {
			System.out.println(test.getTestOne());
			log.info("数据");
		}
		return "Hello";
	}
	
	@GetMapping("login")
	@PassToken
	public String Test0003(HttpServletRequest request) {
		return JWTUtil.createToken(new User(), 1800L, "my_secret");
	}

}
