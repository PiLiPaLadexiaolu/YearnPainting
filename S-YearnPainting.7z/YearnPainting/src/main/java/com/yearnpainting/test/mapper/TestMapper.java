package com.yearnpainting.test.mapper;

import java.util.List;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import com.yearnpainting.test.entity.Test;

@Mapper
public interface TestMapper {

//	 @Select("SELECT id,test_one FROM test")
	 List<Test> getAll();
}
