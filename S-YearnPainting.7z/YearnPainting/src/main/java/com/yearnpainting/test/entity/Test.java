package com.yearnpainting.test.entity;

import lombok.Data;

@Data
public class Test {

	private String id;
	private String testOne;
}
