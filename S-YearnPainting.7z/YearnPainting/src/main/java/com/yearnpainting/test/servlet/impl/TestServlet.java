package com.yearnpainting.test.servlet.impl;

import java.util.List;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import com.yearnpainting.test.entity.Test;
import com.yearnpainting.test.mapper.TestMapper;


public class TestServlet {

	@Autowired
	private TestMapper testMapper;

	public void testSelect() throws Exception {
		List<Test> test = testMapper.getAll();
		System.out.println("?");
	}

}
