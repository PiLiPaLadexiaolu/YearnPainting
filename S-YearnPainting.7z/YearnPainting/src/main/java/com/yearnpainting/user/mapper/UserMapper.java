package com.yearnpainting.user.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import com.yearnpainting.test.entity.Test;
import com.yearnpainting.user.entity.User;

@Mapper
public interface UserMapper {

	 Integer register(User user);
	 
	 User queryUserByUsernameAndPassword(User user);
	 
	 Integer editPayPassword(Map map);
	 
	 User getUserInfo(String id);
	 
	 Integer editRole(Map map);
	 
	 Integer editUserInfo(User user);
	 
	 List<Map> selectPainter(Map map);
	 
	 Map selectPainterAllInfoById(Map map);
	 
	 @Select("SELECT * FROM sys_user WHERE username = #{username}")
	 User getUserByUsername(String username);
	 
	 List<User> queryOpPlanUser(User user);
	 
	 Integer editBan(Map map);
}
