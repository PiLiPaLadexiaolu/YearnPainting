package com.yearnpainting.user.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.yearnpainting.system.annotatin.CheckToken;
import com.yearnpainting.system.utils.JWTUtil;
import com.yearnpainting.user.entity.User;
import com.yearnpainting.user.servlet.UserServlet;
import com.yearnpainting.utils.ResultUtil;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("user")
public class UserController {

	@Autowired
	UserServlet userServlet;
	
	private final static String TOKEN_KEY = "my_secret";

	@CheckToken
	@PutMapping("editPay")
	public ResultUtil<?> editPay(@RequestBody Map<String, String> map, HttpServletRequest request, HttpServletResponse response) {
		// @RequestBody 注解是为了接受前端传过来的JSON字符串
		// User接受数据
		String token = request.getHeader("token");
		User user = JWTUtil.parsingToken(token, TOKEN_KEY);
		map.put("id", user.getId());
		Integer result = userServlet.editPayPassword(map);
		if (result > 0) {
			return ResultUtil.SUCCESS();
		}
		return ResultUtil.FAILURE();
	}
	
	@CheckToken
	@GetMapping("userInfo")
	public ResultUtil<?> userInfo(HttpServletRequest request, HttpServletResponse response) {
		// @RequestBody 注解是为了接受前端传过来的JSON字符串
		// User接受数据
		String token = request.getHeader("token");
		User user = JWTUtil.parsingToken(token, TOKEN_KEY);
		HashMap map = new HashMap<>();
		map.put("id", user.getId());
		User result = userServlet.getUserInfoById(user.getId());
		return ResultUtil.SUCCESS(result);
	}
	
	@CheckToken
	@PutMapping("editRole")
	public ResultUtil<?> editRole(@RequestBody Map<String, String> map, HttpServletRequest request, HttpServletResponse response) {
		// @RequestBody 注解是为了接受前端传过来的JSON字符串
		String token = request.getHeader("token");
		User user = JWTUtil.parsingToken(token, TOKEN_KEY);
		map.put("id", user.getId());
		Integer result = userServlet.editRole(map);
		
		if (result > 0) {
			return ResultUtil.SUCCESS();
		}
		return ResultUtil.FAILURE();
	}
	
	@CheckToken
	@PutMapping("editUserInfo")
	public ResultUtil<?> editUserInfo(@RequestBody User userInfo, HttpServletRequest request, HttpServletResponse response) {
		// @RequestBody 注解是为了接受前端传过来的JSON字符串
		String token = request.getHeader("token");
		User user = JWTUtil.parsingToken(token, TOKEN_KEY);
		userInfo.setId(user.getId());
		Integer result = userServlet.editUserInfo(userInfo);
		if (result > 0) {
			return ResultUtil.SUCCESS();
		}
		return ResultUtil.FAILURE();
	}
	
	/**
	 * 画师搜索页面
	 * @param request
	 * @param response
	 * @return
	 */
	@CheckToken
	@GetMapping("painters")
	public ResultUtil<?> painters(HttpServletRequest request, HttpServletResponse response) {
		// @RequestBody 注解是为了接受前端传过来的JSON字符串
		// User接受数据
		String token = request.getHeader("token");
		User user = JWTUtil.parsingToken(token, TOKEN_KEY);
		HashMap map = new HashMap<>();
		map.put("id", user.getId());
		map.put("realname", request.getParameter("realname"));
		List<Map> result = userServlet.selectPainter(map);
		return ResultUtil.SUCCESS(result);
	}
	
	/**
	 * 企划方管理画面
	 * @param request
	 * @param response
	 * @return
	 */
	@CheckToken
	@GetMapping("opUser")
	public ResultUtil<?> planUser(User user,HttpServletRequest request, HttpServletResponse response) {
		List<User> queryPlanUser = userServlet.queryOpPlanUser(user);
		return ResultUtil.SUCCESS(queryPlanUser);
	}
	
	@CheckToken
	@PutMapping("editBan")
	public ResultUtil<?> editBan(@RequestBody Map userInfo, HttpServletRequest request, HttpServletResponse response) {
		// @RequestBody 注解是为了接受前端传过来的JSON字符串
		String token = request.getHeader("token");
		User user = JWTUtil.parsingToken(token, TOKEN_KEY);
		Integer result = userServlet.editBan(userInfo);
		if (result > 0) {
			return ResultUtil.SUCCESS();
		}
		return ResultUtil.FAILURE();
	}
	
	
}
