package com.yearnpainting.user.servlet;

import java.util.List;
import java.util.Map;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import com.yearnpainting.test.entity.Test;
import com.yearnpainting.test.mapper.TestMapper;
import com.yearnpainting.user.entity.User;


public interface UserServlet {

	/**
	 * 注册用户接口
	 * @param user
	 * @return
	 */
	public boolean register(User user);
	
	/**
	 * 通过用户名和密码查找用户
	 * @param user
	 * @return
	 */
	public User queryUserByUsernameAndPassword(User user);
	
	/**
	 * 修改个人支付密码接口
	 * @param map
	 * @return
	 */
	public Integer editPayPassword(Map map);
	
	/**
	 * 查询个人信息接口
	 * @param map
	 * @return
	 */
	public User getUserInfoById(String id);
	
	/**
	 * 切换权限接口
	 * @param map
	 * @return
	 */
	public Integer editRole(Map map);
	
	/**
	 * 修改个人信息接口
	 * @param user
	 * @return
	 */
	 Integer editUserInfo(User user);
	 
	 /**
	  * 画师搜索页面查询
	  * @param map
	  * @return
	  */
	 List<Map> selectPainter(Map map);
	
	 /**
	  * 通过Username获取用户信息
	  * @param username
	  * @return
	  */
	 User getUserByUsername(String username);
	 
	 
	 /**
	  * 查询企划方
	  * @param user
	  * @return
	  */
	 List<User> queryOpPlanUser(User user);
	 
	 
	 Integer editBan(Map map);
}
