package com.yearnpainting.user.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.yearnpainting.system.annotatin.CheckToken;
import com.yearnpainting.system.annotatin.PassToken;
import com.yearnpainting.system.utils.JWTUtil;
import com.yearnpainting.test.entity.Test;
import com.yearnpainting.test.mapper.TestMapper;
import com.yearnpainting.user.entity.User;
import com.yearnpainting.user.servlet.UserServlet;
import com.yearnpainting.utils.ResultUtil;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("user")
public class LoginController {

	@Autowired
	UserServlet userServlet;

	private final static String TOKEN_KEY = "my_secret";
	
	private final static long TOKEN_TIME = 24*60*60*1000L;
	
	/**
	 * 注册接口
	 * 
	 * @param user
	 * @param request
	 * @param response
	 * @return
	 */
	@PutMapping("register")
	public ResultUtil<?> register(@RequestBody User user, HttpServletRequest request, HttpServletResponse response) {
		// @RequestBody 注解是为了接受前端传过来的JSON字符串
		// User接受数据
		boolean result = userServlet.register(user);
		if (result) {
			return ResultUtil.SUCCESS();
		}
		return ResultUtil.FAILURE();
	}

	@PostMapping("login")
	public ResultUtil<?> login(@RequestBody User user, HttpServletRequest request, HttpServletResponse response) {
		
		User loginUser = userServlet.queryUserByUsernameAndPassword(user);
		if(loginUser!=null) {
			Map<String, String> map = new HashMap<>();
			String token;
			//设置token过期时间为永不过期
			token = JWTUtil.createToken(loginUser, TOKEN_TIME, TOKEN_KEY);
			request.getSession().setAttribute("UserInfo", loginUser);
			map.put("token",token);
			map.put("username",loginUser.getUsername());
			map.put("realname",loginUser.getRealname());
			map.put("id",loginUser.getId());
			map.put("role",loginUser.getRole());
			return ResultUtil.SUCCESS(map);
		}
		return ResultUtil.FAILURE();
	}

}
