package com.yearnpainting.user.entity;

import lombok.Data;

@Data
public class User {

	private String id;
	private String username;
	private String password;
	private String realname;
	private String mail;
	private String tel;
	private String payPassword;
	private String role;
}
