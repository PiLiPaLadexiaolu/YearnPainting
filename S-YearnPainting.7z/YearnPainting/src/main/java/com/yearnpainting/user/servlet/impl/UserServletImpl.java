package com.yearnpainting.user.servlet.impl;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.yearnpainting.attention.mapper.AttentionMapper;
import com.yearnpainting.test.entity.Test;
import com.yearnpainting.test.mapper.TestMapper;
import com.yearnpainting.user.entity.User;
import com.yearnpainting.user.mapper.UserMapper;
import com.yearnpainting.user.servlet.UserServlet;
import com.yearnpainting.utils.UUIDUtil;
import com.yearnpainting.works.entity.Works;
import com.yearnpainting.works.mapper.WorksMapper;

@Service
public class UserServletImpl implements UserServlet {

	@Autowired
	private UserMapper userMapper;
	
	@Autowired
	private WorksMapper worksMapper;
	
	@Autowired
	private AttentionMapper attentionMapper;

	/**
	 * 实现注册接口
	 */
	@Override
	public boolean register(User user) {
		user.setId(UUIDUtil.generate());
		int result = userMapper.register(user);
		if (result == 1) {
			return true;
		}
		return false;
	}

	/**
	 * 通过用户名密码查找用户
	 */
	@Override
	public User queryUserByUsernameAndPassword(User user) {
		return userMapper.queryUserByUsernameAndPassword(user);
	}

	@Override
	public Integer editPayPassword(Map map) {
		return userMapper.editPayPassword(map);
	}
	
	@Override
	public User getUserInfoById(String id) {
		return userMapper.getUserInfo(id);
	}
	
	@Override
	public Integer editRole(Map map) {
		
		return userMapper.editRole(map);
	}
	
	@Override
	public Integer editUserInfo(User user) {
		return userMapper.editUserInfo(user);
	}
	
	@Override
	public List<Map> selectPainter(Map map) {
		//存放查询条件
		List<Map> lists = userMapper.selectPainter(map);
		for (Map listmap : lists) {
			//查询改用户前三个作品
			String userid = (String) listmap.get("id");
			//处理标签对象
			List<Works> works = worksMapper.selectUserWorksById(userid);
			for (Works work : works) {
				work.setFileTags(work.getFileTag().split(","));
			}
			listmap.put("works",works);
			//处理关注状态 0 未关注 1 关注
			int attentionStatus = attentionMapper.selectAttentionStatus(map.get("id").toString(), userid);
			listmap.put("attentionStatus", attentionStatus);
			//关注接口单独设置 增加复用性
		}
		return lists;
		
	}
	
	@Override
	public User getUserByUsername(String username) {
		return userMapper.getUserByUsername(username);
	}

	@Override
	public List<User> queryOpPlanUser(User user) {
		return userMapper.queryOpPlanUser(user);
	}

	@Override
	public Integer editBan(Map map) {
		return userMapper.editBan(map);
	}



}
