package com.yearnpainting.utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.UUID;

public class DateUtil {
	/**
	 * 获取当前时间
	 * 格式yyyyMMddHHmmss
	 * @return
	 */
	public static String nowTimeNumber() {
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");
        String time = format.format(new Date());
		return time; 
	}
	
	public static String dateToTimeNumber(Date date) {
		SimpleDateFormat format = new SimpleDateFormat("yyyyMMddHHmmss");
        String time = format.format(date);
		return time; 
	}
}
