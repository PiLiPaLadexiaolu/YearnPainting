package com.yearnpainting.order.servlet.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.yearnpainting.test.entity.Test;
import com.yearnpainting.test.mapper.TestMapper;
import com.yearnpainting.user.entity.User;
import com.yearnpainting.user.mapper.UserMapper;
import com.yearnpainting.user.servlet.UserServlet;
import com.yearnpainting.utils.UUIDUtil;
import com.yearnpainting.works.entity.Works;
import com.yearnpainting.works.mapper.WorksMapper;
import com.yearnpainting.attention.mapper.AttentionMapper;
import com.yearnpainting.order.entity.Order;
import com.yearnpainting.order.mapper.OrderMapper;
import com.yearnpainting.order.servlet.OrderServlet;
import com.yearnpainting.works.servlet.WorksServlet;

@Service
public class OrderServletImpl implements OrderServlet {

	@Value("${file-upload.upload-path}")
	public String uploadPath;

	@Autowired
	WorksMapper worksMapper;

	@Autowired
	UserMapper userMapper;
	
	@Autowired
	AttentionMapper attentionMapper;

	@Autowired
	OrderMapper orderMapper;
	
	@Override
	public Integer insertOrder(Order order) {
		// TODO Auto-generated method stub
		return orderMapper.insertOrder(order);
	}
 
	@Override
	public List<Order> queryOrderByUserId(Order order) {
		return orderMapper.queryOrderByUserId(order);
	}

	@Override
	public Integer updateOrder(Order order) {
		return orderMapper.updateOrder(order);
	}
	
	@Override
	public List<Order> queryOpOrder(Order order) {
		return orderMapper.queryOpOrder(order);
	}

	@Override
	public Integer updateOpOrder(Order order) {
		return orderMapper.updateOpOrder(order);
	}
	
	
}
