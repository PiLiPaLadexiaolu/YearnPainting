package com.yearnpainting.order.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.yearnpainting.order.entity.Order;
import com.yearnpainting.test.entity.Test;
import com.yearnpainting.user.entity.User;
import com.yearnpainting.works.entity.Works;

@Mapper
public interface OrderMapper {
	/**
	 * 
	 * @param order
	 * @return
	 */
	Integer insertOrder(Order order);
	
	List<Order> queryOrderByUserId(Order order);
	
	@Update("UPDATE `order` SET `feedback`=#{feedback} WHERE  `id`=#{id}")
	Integer updateOrder(Order order);
	
	List<Order> queryOpOrder(Order order);
	
	@Update("UPDATE `order` SET `order_status`=#{orderStatus} WHERE  `id`=#{id}")
	Integer updateOpOrder(Order order);
}
