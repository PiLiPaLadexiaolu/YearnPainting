package com.yearnpainting.order.entity;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class Order {

	private String id;
	private String planningId;
	/**
	 * 企划标题
	 */
	private String planningType;
	private String content;
	private String title;
	private String fileSize;
	private String orderStatus;
	private String feedback;
	private String refund;
	private String reason;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy年MM月dd HH:mm:ss", timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy年MM月dd HH:mm:ss")
	private Date createTime;
	private String userId;
}
