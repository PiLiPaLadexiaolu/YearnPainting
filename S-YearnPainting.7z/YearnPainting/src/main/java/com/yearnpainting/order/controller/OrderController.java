package com.yearnpainting.order.controller;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.GsonBuilderUtils;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.yearnpainting.order.entity.Order;
import com.yearnpainting.order.servlet.OrderServlet;
import com.yearnpainting.planning.entity.Planning;
import com.yearnpainting.release.entity.ReleaseVo;
import com.yearnpainting.system.annotatin.CheckToken;
import com.yearnpainting.system.utils.JWTUtil;
import com.yearnpainting.user.entity.User;
import com.yearnpainting.user.servlet.UserServlet;
import com.yearnpainting.utils.DateUtil;
import com.yearnpainting.utils.ResultUtil;
import com.yearnpainting.utils.UUIDUtil;
import com.yearnpainting.works.entity.Works;
import com.yearnpainting.works.servlet.WorksServlet;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("order")
public class OrderController {

	@Autowired
	UserServlet userServlet;

	@Value("${file-upload.upload-path}")
	public String uploadPath;

	private final static String TOKEN_KEY = "my_secret";

	@Autowired
	OrderServlet orderServlet;

	/**
	 * 添加订单信息
	 * @param planning
	 * @param request
	 * @param response
	 * @return
	 */
	@PostMapping("order")
	public ResultUtil<?> addOrder(@RequestBody ReleaseVo releaseVo, HttpServletRequest request,
			HttpServletResponse response) {
		// 接收token
		String token = request.getHeader("token");
		// 获取当前登录用户信息
		User user = JWTUtil.parsingToken(token, TOKEN_KEY);
		Order order = new Order();
		order.setCreateTime(new Date());
		order.setId(UUIDUtil.generate());
		order.setPlanningId(releaseVo.getPlanningId());
		order.setRefund("0");
		order.setOrderStatus("0");
		order.setUserId(user.getId());
		int result = orderServlet.insertOrder(order);
		if (result > 0) {
			return ResultUtil.SUCCESS();
		}
		return ResultUtil.FAILURE();
	}
	
	@GetMapping("order")
	public ResultUtil<?> allOrder(Order order, HttpServletRequest request,
			HttpServletResponse response) {
		// 接收token
		String token = request.getHeader("token");
		// 获取当前登录用户信息
		User user = JWTUtil.parsingToken(token, TOKEN_KEY);
		order.setUserId(user.getId());
		List<Order> result = orderServlet.queryOrderByUserId(order);
		return ResultUtil.SUCCESS(result);

	}
	
	@PutMapping("order")
	public ResultUtil<?> editOrder(@RequestBody Order order, HttpServletRequest request,
			HttpServletResponse response) {
		// 接收token
		String token = request.getHeader("token");
		// 获取当前登录用户信息
		User user = JWTUtil.parsingToken(token, TOKEN_KEY);
		int result = orderServlet.updateOrder(order);
		if (result > 0) {
			return ResultUtil.SUCCESS();
		}
		return ResultUtil.FAILURE();
	}
	
	@GetMapping("opOrder")
	public ResultUtil<?> opOrder(Order order, HttpServletRequest request,
			HttpServletResponse response) {
		// 接收token
		String token = request.getHeader("token");
		// 获取当前登录用户信息
		User user = JWTUtil.parsingToken(token, TOKEN_KEY);
		order.setUserId(user.getId());
		List<Order> result = orderServlet.queryOpOrder(order);
		return ResultUtil.SUCCESS(result);
	}
	
	@PutMapping("editOpOrder")
	public ResultUtil<?> editOpOrder(@RequestBody Order order, HttpServletRequest request,
			HttpServletResponse response) {
		// 接收token
		String token = request.getHeader("token");
		// 获取当前登录用户信息
		User user = JWTUtil.parsingToken(token, TOKEN_KEY);
		int result = orderServlet.updateOpOrder(order);
		if (result > 0) {
			return ResultUtil.SUCCESS();
		}
		return ResultUtil.FAILURE();
	}
}
