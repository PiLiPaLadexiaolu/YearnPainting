package com.yearnpainting.attention.servlet.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.yearnpainting.attention.mapper.AttentionMapper;
import com.yearnpainting.attention.servlet.AttentionServlet;
import com.yearnpainting.test.entity.Test;
import com.yearnpainting.test.mapper.TestMapper;
import com.yearnpainting.user.entity.User;
import com.yearnpainting.user.mapper.UserMapper;
import com.yearnpainting.user.servlet.UserServlet;
import com.yearnpainting.utils.UUIDUtil;
import com.yearnpainting.works.entity.Works;
import com.yearnpainting.works.mapper.WorksMapper;
import com.yearnpainting.works.servlet.WorksServlet;

@Service
public class AttentionServletImpl implements AttentionServlet {

	@Value("${file-upload.upload-path}")
	public String uploadPath;
	
	@Autowired
	WorksMapper worksMapper;
	
	@Autowired
	AttentionMapper attentionMapper;

	@Override
	public Integer selectAttentionStatus(String userId, String followUserId) {
		return attentionMapper.selectAttentionStatus(userId, followUserId);
	}

	@Override
	public Integer insertAttention(String userId, String followUserId) {
		return attentionMapper.insertAttention(userId, followUserId);
	}

	@Override
	public Integer deleteAttention(String userId, String followUserId) {
		return attentionMapper.deleteAttention(userId, followUserId);
	}

	
	
}
