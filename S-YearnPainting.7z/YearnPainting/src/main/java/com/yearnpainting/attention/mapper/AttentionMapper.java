package com.yearnpainting.attention.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.yearnpainting.test.entity.Test;
import com.yearnpainting.user.entity.User;
import com.yearnpainting.works.entity.Works;

@Mapper
public interface AttentionMapper {
	
	@Select("SELECT COUNT(1) FROM user_attention WHERE user_id = #{userId} AND follow_user_id = #{followUserId}")
	Integer selectAttentionStatus(String userId,String followUserId);
	
	@Insert("INSERT INTO user_attention (user_id, follow_user_id) VALUES (#{userId}, #{followUserId})")
	Integer insertAttention(String userId,String followUserId);
	
	@Delete("DELETE FROM user_attention WHERE user_id = #{userId} AND follow_user_id = #{followUserId}")
	Integer deleteAttention(String userId,String followUserId);
}
