package com.yearnpainting.attention.controller;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.GsonBuilderUtils;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.yearnpainting.attention.mapper.AttentionMapper;
import com.yearnpainting.attention.servlet.AttentionServlet;
import com.yearnpainting.system.annotatin.CheckToken;
import com.yearnpainting.system.utils.JWTUtil;
import com.yearnpainting.user.entity.User;
import com.yearnpainting.utils.DateUtil;
import com.yearnpainting.utils.ResultUtil;
import com.yearnpainting.works.entity.Works;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("attention")
public class AttentionController {


	@Value("${file-upload.upload-path}")
	public String uploadPath;

	private final static String TOKEN_KEY = "my_secret";

	@Autowired
	AttentionServlet attentionServlet;

	/**
	 * 添加关注数据
	 * 
	 * @param map
	 * @param request
	 * @param response
	 * @return
	 */
	@CheckToken
	@PostMapping("addAttention")
	public ResultUtil<?> addAttention(@RequestBody Map<String, String> map, HttpServletRequest request,
			HttpServletResponse response) {
		// @RequestBody 注解是为了接受前端传过来的JSON字符串
		// User接受数据
		String token = request.getHeader("token");
		// 获取当前用户
		User user = JWTUtil.parsingToken(token, TOKEN_KEY);
		map.put("id", user.getId());
		Integer result = attentionServlet.insertAttention(user.getId(), map.get("followUserId"));
		if (result > 0) {
			return ResultUtil.SUCCESS();
		}
		return ResultUtil.FAILURE();
	}

	/**
	 * 删除关注数据
	 * 
	 * @param map
	 * @param request
	 * @param response
	 * @return
	 */
	@CheckToken
	@DeleteMapping("deleteAttention")
	public ResultUtil<?> deleteAttention(@RequestBody Map<String, String> map, HttpServletRequest request,
			HttpServletResponse response) {
		// @RequestBody 注解是为了接受前端传过来的JSON字符串
		// User接受数据
		String token = request.getHeader("token");
		// 获取当前用户
		User user = JWTUtil.parsingToken(token, TOKEN_KEY);
		map.put("id", user.getId());
		Integer result = attentionServlet.deleteAttention(user.getId(), map.get("followUserId"));
		if (result > 0) {
			return ResultUtil.SUCCESS();
		}
		return ResultUtil.FAILURE();
	}

	/**
	 * 获取关注状态
	 * 
	 * @param map
	 * @param request
	 * @param response
	 * @return
	 */
	@CheckToken
	@GetMapping("getAttention")
	public ResultUtil<?> getAttention(@RequestBody Map<String, String> map, HttpServletRequest request,
			HttpServletResponse response) {
		// @RequestBody 注解是为了接受前端传过来的JSON字符串
		// User接受数据
		String token = request.getHeader("token");
		// 获取当前用户
		User user = JWTUtil.parsingToken(token, TOKEN_KEY);
		map.put("id", user.getId());
		Integer result = attentionServlet.selectAttentionStatus(user.getId(), map.get("followUserId"));
		return ResultUtil.SUCCESS(result);

	}

}
