package com.yearnpainting.painterapplication.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.yearnpainting.painterapplication.entity.Certification;
import com.yearnpainting.test.entity.Test;
import com.yearnpainting.user.entity.User;
import com.yearnpainting.works.entity.Works;

@Mapper
public interface CertificationMapper {
	
	@Insert("INSERT INTO certification (`id`, `user_id`, `id_card`, `actual_name`, `create_time`, `approve`,`blockade`) VALUES (#{id}, #{userId}, #{idCard}, #{actualName}, #{createTime}, #{approve},0)")
	Integer insertCertification(Certification certification);
	
	List<Certification> queryCertification(Certification certification);
	
	@Update("UPDATE `certification` SET `approve`=#{approve} WHERE  `id`=#{id}")
	Integer updateCertification(Certification certification);
	
	List<Map> queryOpPainter(Map map);
	
	@Update("UPDATE `certification` SET `blockade`=#{blockade} WHERE  `id`=#{id}")
	Integer updateCertificationBlockade(Certification certification);
	
}
