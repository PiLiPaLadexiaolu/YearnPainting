package com.yearnpainting.painterapplication.servlet.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.yearnpainting.test.entity.Test;
import com.yearnpainting.test.mapper.TestMapper;
import com.yearnpainting.user.entity.User;
import com.yearnpainting.user.mapper.UserMapper;
import com.yearnpainting.user.servlet.UserServlet;
import com.yearnpainting.utils.UUIDUtil;
import com.yearnpainting.works.entity.Works;
import com.yearnpainting.works.mapper.WorksMapper;
import com.yearnpainting.attention.mapper.AttentionMapper;
import com.yearnpainting.painterapplication.entity.Certification;
import com.yearnpainting.painterapplication.mapper.CertificationMapper;
import com.yearnpainting.painterapplication.servlet.CertificationServlet;
import com.yearnpainting.works.servlet.WorksServlet;

@Service
public class CertificationServletImpl implements CertificationServlet {

	@Value("${file-upload.upload-path}")
	public String uploadPath;

	@Autowired
	WorksMapper worksMapper;

	@Autowired
	UserMapper userMapper;
	
	@Autowired
	AttentionMapper attentionMapper;
	
	@Autowired
	CertificationMapper certificationMapper;

	@Override
	public Integer insertCertification(Certification certification) {
		return certificationMapper.insertCertification(certification);
	}

	@Override
	public List<Certification> queryCertification(Certification certification) {
		return certificationMapper.queryCertification(certification);
	}

	@Override
	public Integer updateCertification(Certification certification) {
		return certificationMapper.updateCertification(certification);
	}

	@Override
	public List<Map> queryOpPainter(Map map) {
		return certificationMapper.queryOpPainter(map);
	}

	@Override
	public Integer updateCertificationBlockade(Certification certification) {
		return certificationMapper.updateCertificationBlockade(certification);
	}

 

}
