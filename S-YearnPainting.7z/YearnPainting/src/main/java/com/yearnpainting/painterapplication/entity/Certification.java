package com.yearnpainting.painterapplication.entity;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class Certification {

	private String id;
	private String idCard;
	private String actualName;
	private String userId;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy年MM月dd HH:mm:ss", timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy年MM月dd HH:mm:ss")
	private Date createTime;
	private String approve;
	private String blockade;
}
