package com.yearnpainting.painterapplication.controller;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.GsonBuilderUtils;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.yearnpainting.painterapplication.entity.Certification;
import com.yearnpainting.painterapplication.mapper.CertificationMapper;
import com.yearnpainting.painterapplication.servlet.CertificationServlet;
import com.yearnpainting.planning.entity.Planning;
import com.yearnpainting.system.annotatin.CheckToken;
import com.yearnpainting.system.utils.JWTUtil;
import com.yearnpainting.user.entity.User;
import com.yearnpainting.user.servlet.UserServlet;
import com.yearnpainting.utils.DateUtil;
import com.yearnpainting.utils.ResultUtil;
import com.yearnpainting.utils.UUIDUtil;
import com.yearnpainting.works.entity.Works;
import com.yearnpainting.works.servlet.WorksServlet;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("certification")
public class CertificationController {

	@Autowired
	UserServlet userServlet;

	@Value("${file-upload.upload-path}")
	public String uploadPath;

	private final static String TOKEN_KEY = "my_secret";

	@Autowired
	CertificationServlet certificationServlet;

	@PostMapping("certification")
	public ResultUtil<?> addCertification(@RequestBody Certification certification, HttpServletRequest request,
			HttpServletResponse response) {
		// 接收token
		String token = request.getHeader("token");
		// 获取当前登录用户信息
		User user = JWTUtil.parsingToken(token, TOKEN_KEY);
		certification.setId(UUIDUtil.generate());
		certification.setUserId(user.getId());
		certification.setCreateTime(new Date());
		certification.setApprove("0");
		int result = certificationServlet.insertCertification(certification);
		if (result > 0) {
			return ResultUtil.SUCCESS();
		}
		return ResultUtil.FAILURE();
	}
	
	@GetMapping("certification")
	public ResultUtil<?> getCertification( Certification certification, HttpServletRequest request,
			HttpServletResponse response) {
		// 接收token
		String token = request.getHeader("token");
		// 获取当前登录用户信息
		User user = JWTUtil.parsingToken(token, TOKEN_KEY);
		List<Certification> result = certificationServlet.queryCertification(certification);
		return ResultUtil.SUCCESS(result);
	}
	
	@PutMapping("certification")
	public ResultUtil<?> editCertification(@RequestBody Certification certification, HttpServletRequest request,
			HttpServletResponse response) {
		// 接收token
		String token = request.getHeader("token");
		// 获取当前登录用户信息
		User user = JWTUtil.parsingToken(token, TOKEN_KEY);
		int result = certificationServlet.updateCertification(certification);
		if (result > 0) {
			return ResultUtil.SUCCESS();
		}
		return ResultUtil.FAILURE();
	}
	
	//管理画师画面的处理
	@GetMapping("opPainter")
	public ResultUtil<?> handler(Map map, HttpServletRequest request,
			HttpServletResponse response) {
		// 获取当前登录用户信息
		List<Map> result = certificationServlet.queryOpPainter(map);
		return ResultUtil.SUCCESS(result);
	}
	
	@PutMapping("opCertification")
	public ResultUtil<?> opCertification(@RequestBody Certification certification, HttpServletRequest request,
			HttpServletResponse response) {
		// 接收token
		String token = request.getHeader("token");
		// 获取当前登录用户信息
		User user = JWTUtil.parsingToken(token, TOKEN_KEY);
		int result = certificationServlet.updateCertificationBlockade(certification);
		if (result > 0) {
			return ResultUtil.SUCCESS();
		}
		return ResultUtil.FAILURE();
	}
	
	
	

}
