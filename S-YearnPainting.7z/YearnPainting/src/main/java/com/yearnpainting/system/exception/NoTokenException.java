package com.yearnpainting.system.exception;

public class NoTokenException extends BaseException {
	
}
