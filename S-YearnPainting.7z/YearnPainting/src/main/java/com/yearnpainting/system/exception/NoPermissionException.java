package com.yearnpainting.system.exception;

public class NoPermissionException extends BaseException{

}
