package com.yearnpainting.system.exceptionprocess;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@ControllerAdvice
@ResponseBody
public class WebExceptionHandle {

	/**
	 * 全局异常
	 * @param e
	 * @return
	 */
	@ExceptionHandler(Exception.class)
	public String handleHttpRequestMethodNotSupportedException(Exception e) {
		log.error("全部异常捕获", e);
		return "服务器好像抽风了呢(⊙﹏⊙)";
	}
}