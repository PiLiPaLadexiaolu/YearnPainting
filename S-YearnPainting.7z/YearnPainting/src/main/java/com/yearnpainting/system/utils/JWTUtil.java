package com.yearnpainting.system.utils;

import java.io.UnsupportedEncodingException;
import java.util.Base64;
import java.util.Date;
import java.util.Map;

import com.auth0.jwt.JWT;
import com.auth0.jwt.JWTVerifier;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.auth0.jwt.interfaces.Claim;
import com.auth0.jwt.interfaces.DecodedJWT;
import com.yearnpainting.user.entity.User;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class JWTUtil {
	private static final String EXP = "exp";

	private static final String PAYLOAD = "payload";

	/**
	 * 加密生成token
	 *
	 * @param object 载体信息
	 * @param maxAge 有效时长
	 * @param secret 服务器私钥
	 * @param <T>
	 * @return
	 */
	public static String createToken(User user, long maxAge, String secret) {
		try {
			final Algorithm signer = Algorithm.HMAC256(secret);// 生成签名
			String token = JWT.create().withIssuer("签发者").withSubject("用户")// 主题，科目
					.withClaim("username", user.getUsername()).withClaim("id", user.getId())
					.withClaim("password", user.getPassword()).withClaim("mail", user.getMail()).withClaim("role", user.getRole())
					.withExpiresAt(new Date(System.currentTimeMillis() + maxAge)).sign(signer);
			System.out.println(token);
			//return Base64.getEncoder().encodeToString(token.getBytes("utf-8"));
			return token;
		} catch (Exception e) {
			log.error("生成token异常：", e);
			return null;
		}
	}

	/**
	 * 解析验证token
	 *
	 * @param token  加密后的token字符串
	 * @param secret 服务器私钥
	 * @return
	 */
	public static Boolean verifyToken(String token, String secret) {
		try {
			Algorithm algorithm = Algorithm.HMAC256(secret);
			JWTVerifier verifier = JWT.require(algorithm).build();
			//DecodedJWT jwt = verifier.verify(new String(Base64.getDecoder().decode(token), "utf-8"));
			DecodedJWT jwt = verifier.verify(token);
			// 应该验证token
			return true;
		} catch (IllegalArgumentException e) {
//            throw new AppException("9999",e.getMessage());
		} catch (JWTVerificationException e) {
//            throw new AppException("9999",e.getMessage());
		}
		return false;
	}
	
	/**
	 * 解析验证token
	 *
	 * @param token  加密后的token字符串
	 * @param secret 服务器私钥
	 * @return
	 */
	public static User parsingToken(String token, String secret) {
		User user = null;
		try {
			Algorithm algorithm = Algorithm.HMAC256(secret);
			JWTVerifier verifier = JWT.require(algorithm).build();
			//DecodedJWT jwt = verifier.verify(new String(Base64.getDecoder().decode(token), "utf-8"));
			DecodedJWT jwt = verifier.verify(token);
			Map<String, Claim> claim = jwt.getClaims();
			user = new User();
			user.setId(claim.get("id").asString());
			user.setUsername(claim.get("username").asString());
			user.setPassword(claim.get("password").asString());
			if(claim.get("mail")==null) {
				user.setMail(null);
			}else {
				user.setMail(claim.get("mail").asString());
			}
			if(claim.get("tel")==null) {
				user.setTel(null);
			}else {
				user.setTel(claim.get("tel").asString());
			}
			// 应该验证token
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (JWTVerificationException e) {
			e.printStackTrace();
		}
		return user;
	}
}