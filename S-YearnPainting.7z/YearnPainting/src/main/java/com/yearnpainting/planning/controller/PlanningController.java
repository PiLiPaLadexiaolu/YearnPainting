package com.yearnpainting.planning.controller;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.GsonBuilderUtils;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.yearnpainting.planning.entity.Planning;
import com.yearnpainting.planning.servlet.PlanningServlet;
import com.yearnpainting.release.entity.ReleaseVo;
import com.yearnpainting.system.annotatin.CheckToken;
import com.yearnpainting.system.utils.JWTUtil;
import com.yearnpainting.user.entity.User;
import com.yearnpainting.user.servlet.UserServlet;
import com.yearnpainting.utils.DateUtil;
import com.yearnpainting.utils.UUIDUtil;
import com.yearnpainting.utils.ResultUtil;
import com.yearnpainting.works.entity.Works;
import com.yearnpainting.works.servlet.WorksServlet;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("planning")
public class PlanningController {

	@Autowired
	UserServlet userServlet;

	@Value("${file-upload.upload-path}")
	public String uploadPath;

	private final static String TOKEN_KEY = "my_secret";

	@Autowired
	PlanningServlet planningServlet;

	@PostMapping("planning")
	public ResultUtil<?> addPlanning(@RequestBody Planning planning, HttpServletRequest request,
			HttpServletResponse response) {
		// 接收token
		String token = request.getHeader("token");
		// 获取当前登录用户信息
		User user = JWTUtil.parsingToken(token, TOKEN_KEY);
		planning.setCreateUserId(user.getId());
		planning.setId(UUIDUtil.generate());
		planning.setCreateTime(new Date());
		int result = planningServlet.insertPlanning(planning);
		if (result > 0) {
			return ResultUtil.SUCCESS();
		}
		return ResultUtil.FAILURE();
	}

	@GetMapping("planning")
	public ResultUtil<?> allPlanning(Planning planning, HttpServletRequest request,
			HttpServletResponse response) {
		// 接收token
		String token = request.getHeader("token");
		// 获取当前登录用户信息
		User user = JWTUtil.parsingToken(token, TOKEN_KEY);
		planning.setCreateUserId(user.getId());
		List<Planning> result = planningServlet.queryPlanningByUserId(planning);
		return ResultUtil.SUCCESS(result);

	}
	
	@GetMapping("publicPlanning")
	public ResultUtil<?> allPublicPlanning(Planning planning, HttpServletRequest request,
			HttpServletResponse response) {
		// 接收token
		String token = request.getHeader("token");
		// 获取当前登录用户信息
		User user = JWTUtil.parsingToken(token, TOKEN_KEY);
		planning.setCreateUserId(user.getId());
		List<ReleaseVo> result = planningServlet.queryPublicPlanning(planning);
		return ResultUtil.SUCCESS(result);

	}
	
	@CheckToken
	@DeleteMapping("planning")
	public ResultUtil<?> deletePlanning(@RequestBody Planning planning, HttpServletRequest request,
			HttpServletResponse response) {
		// 接收token
		String token = request.getHeader("token");
		// 获取当前登录用户信息
		User user = JWTUtil.parsingToken(token, TOKEN_KEY);
		System.out.println(planning.getId());
		int result = planningServlet.deletePlanning(planning.getId());
		if(result > 0) {
			return ResultUtil.SUCCESS();
		}
		return ResultUtil.FAILURE();
	}
	
	@GetMapping("inviteMePlanning")
	public ResultUtil<?> inviteMePlanning(Planning planning, HttpServletRequest request,
			HttpServletResponse response) {
		// 接收token
		String token = request.getHeader("token");
		// 获取当前登录用户信息
		User user = JWTUtil.parsingToken(token, TOKEN_KEY);
		planning.setCreateUserId(user.getId());
		List<Planning> result = planningServlet.queryPlanningByUserId(planning);
		return ResultUtil.SUCCESS(result);

	}
	
	@GetMapping("planningDetail")
	public ResultUtil<?> planningDetail(Planning planning, HttpServletRequest request,
			HttpServletResponse response) {
		// 接收token
		String token = request.getHeader("token");
		// 获取当前登录用户信息
		User user = JWTUtil.parsingToken(token, TOKEN_KEY);
		Planning result = planningServlet.queryPlanningById(planning.getId());
		return ResultUtil.SUCCESS(result);

	}
	
	
}
