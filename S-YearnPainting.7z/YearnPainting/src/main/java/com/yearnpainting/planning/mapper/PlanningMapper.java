package com.yearnpainting.planning.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.yearnpainting.planning.entity.Planning;
import com.yearnpainting.release.entity.ReleaseVo;
import com.yearnpainting.test.entity.Test;
import com.yearnpainting.user.entity.User;
import com.yearnpainting.works.entity.Works;

@Mapper
public interface PlanningMapper {
	@Insert("INSERT INTO planning (id, `use`, end_time, min_money, max_money, title, content, planning_type, create_user_id, acceptance_stage, create_time , status) VALUES (#{id}, #{use}, #{endTime}, #{minMoney}, #{maxMoney}, #{title}, #{content}, #{planningType}, #{createUserId}, #{acceptanceStage}, #{createTime}, 0)")
	Integer insertPlanning(Planning planning);
	
	
	List<Planning> queryPlanningByUserId(Planning planning);
	
	@Delete("DELETE FROM planning WHERE id = #{id}")
	Integer deletePlanning(String id);
	
	List<ReleaseVo> queryPublicPlanning(Planning planning);
	
	@Select("SELECT * FROM planning WHERE id = #{id}")
	Planning queryPlanningById(String id);
	
}
