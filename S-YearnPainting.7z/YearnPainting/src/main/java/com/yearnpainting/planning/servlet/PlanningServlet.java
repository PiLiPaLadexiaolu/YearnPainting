package com.yearnpainting.planning.servlet;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import com.yearnpainting.planning.entity.Planning;
import com.yearnpainting.release.entity.ReleaseVo;
import com.yearnpainting.test.entity.Test;
import com.yearnpainting.test.mapper.TestMapper;
import com.yearnpainting.user.entity.User;
import com.yearnpainting.works.entity.Works;


public interface PlanningServlet {

	Integer insertPlanning(Planning planning);
	
	List<Planning> queryPlanningByUserId(Planning planning);
	
	Integer deletePlanning(String id);
	
	List<ReleaseVo> queryPublicPlanning(Planning planning);
	
	Planning queryPlanningById(String id);
}
