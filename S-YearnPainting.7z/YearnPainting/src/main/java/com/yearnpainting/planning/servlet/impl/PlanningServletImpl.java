package com.yearnpainting.planning.servlet.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.yearnpainting.test.entity.Test;
import com.yearnpainting.test.mapper.TestMapper;
import com.yearnpainting.user.entity.User;
import com.yearnpainting.user.mapper.UserMapper;
import com.yearnpainting.user.servlet.UserServlet;
import com.yearnpainting.utils.UUIDUtil;
import com.yearnpainting.works.entity.Works;
import com.yearnpainting.works.mapper.WorksMapper;
import com.yearnpainting.attention.mapper.AttentionMapper;
import com.yearnpainting.planning.entity.Planning;
import com.yearnpainting.planning.mapper.PlanningMapper;
import com.yearnpainting.planning.servlet.PlanningServlet;
import com.yearnpainting.release.entity.ReleaseVo;
import com.yearnpainting.works.servlet.WorksServlet;

@Service
public class PlanningServletImpl implements PlanningServlet {

	@Value("${file-upload.upload-path}")
	public String uploadPath;

	@Autowired
	PlanningMapper planningMapper;

	@Autowired
	UserMapper userMapper;
	
	@Autowired
	AttentionMapper attentionMapper;
	
 
	public Integer insertPlanning(Planning planngin) {
		return planningMapper.insertPlanning(planngin);
	}


	@Override
	public List<Planning> queryPlanningByUserId(Planning planning) {
		return planningMapper.queryPlanningByUserId(planning);
	}
	
	@Override
	public Integer deletePlanning(String id) {
		return planningMapper.deletePlanning(id);
	}
	
	@Override
	public List<ReleaseVo> queryPublicPlanning(Planning planning) {
		return planningMapper.queryPublicPlanning(planning);
	}


	@Override
	public Planning queryPlanningById(String id) {
		return planningMapper.queryPlanningById(id);
	}
}
