package com.yearnpainting.works.servlet.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.yearnpainting.test.entity.Test;
import com.yearnpainting.test.mapper.TestMapper;
import com.yearnpainting.user.entity.User;
import com.yearnpainting.user.mapper.UserMapper;
import com.yearnpainting.user.servlet.UserServlet;
import com.yearnpainting.utils.UUIDUtil;
import com.yearnpainting.works.entity.Works;
import com.yearnpainting.works.mapper.WorksMapper;
import com.yearnpainting.attention.mapper.AttentionMapper;
import com.yearnpainting.works.servlet.WorksServlet;

@Service
public class WorksServletImpl implements WorksServlet {

	@Value("${file-upload.upload-path}")
	public String uploadPath;

	@Autowired
	WorksMapper worksMapper;

	@Autowired
	UserMapper userMapper;
	
	@Autowired
	AttentionMapper attentionMapper;
 
	@Transactional(rollbackFor = Exception.class)
	@Override
	public boolean uploadUserWorks(String filePath, String fileTag, String fileDescription, User user,
			Date createTime) {
		File file = new File(filePath);

		Works works = new Works();
		works.setCreateTime(createTime);
		works.setFileDescription(fileDescription);
		works.setFileName(file.getName());
		works.setFileSize(String.valueOf(file.length()));
		works.setFileTag(fileTag);
		works.setId(UUIDUtil.generate());
		works.setUserId(user.getId());

		int result = worksMapper.insertWorks(works);
		if (result > 0) {
			return true;
		}
		return false;
	}

	/**
	 * 获取封面文件
	 */
	@Override
	public ResponseEntity<byte[]> getCover(String coverName) throws Exception {
		String fileName = coverName;
		File file = new File(uploadPath + fileName);
		byte[] buff;
		if (!file.isFile()) {
			file = new File(uploadPath + "default.jpg");
		}

		try {
			@SuppressWarnings("resource")
			InputStream input = new FileInputStream(file);
			buff = new byte[input.available()]; // 获取文件大小
			input.read(buff);
		} catch (Exception e) {
			throw e;
		}
		//更新改作品点击次数
		worksMapper.updateCheckNumber(fileName);
		HttpHeaders headers = new HttpHeaders();
		headers.add("Content-Disposition", "attachment;filename=" + fileName);
		HttpStatus status = HttpStatus.OK;
		ResponseEntity<byte[]> entity = new ResponseEntity<byte[]>(buff, headers, status);
		return entity;
	}

	@Override
	public List<Works> selectUserWorks(String userId, String start, String number) {
		List<Works> list = worksMapper.selectUserWorks(userId, start, number);
		// 将数据库存储的标签进行特殊处理
		for (Works works : list) {
			works.setFileTags(works.getFileTag().split(","));
		}
		return list;
	}

	@Override
	public Integer updateWorks(Works works) {
		return worksMapper.updateWorks(works);
	}

	@Override
	public Integer deleteWorks(Works works) {
		return worksMapper.deleteWorks(works);
	}

	@Override
	public Map selectUserWorksByUserId(Map userMap,String userId) {
		Map map = new HashMap<>();
		map.put("id", userId);
		Map user = userMapper.selectPainterAllInfoById(map);
		String str = user.get("id").toString();
		List<Works> works = worksMapper.selectUserWorksByUserId(str);
		
		//处理标签对象
		for (Works work : works) {
			work.setFileTags(work.getFileTag().split(","));
		}
		user.put("works", works);
		//处理关注状态 0 未关注 1 关注
		int attentionStatus = attentionMapper.selectAttentionStatus(userMap.get("userId").toString(), userId);
		user.put("attentionStatus", attentionStatus);
		//关注接口单独设置 增加复用性
		return user;
	}
	
	@Override
	public List<Works> selectCreateTimeOrderByDesc(String tag) {
		return worksMapper.selectCreateTimeOrderByDesc(tag);
	}
	
	@Override
	public List<Works> selectFollowContent(String tag, String userId) {
		return worksMapper.selectFollowContent(tag, userId);
	}

	@Override
	public List<Works> selectOpWorks(Works works) {
		List<Works> list = worksMapper.selectOpWorks(works);
		// 将数据库存储的标签进行特殊处理
		for (Works work : list) {
			work.setFileTags(work.getFileTag().split(","));
		}
		return list;
	}

	@Override
	public List<Works> selectPopularityContentOrderByDesc(String tag) {
		return worksMapper.selectPopularityContentOrderByDesc(tag);
	}

	@Override
	public List<Works> selectRecentlyPopularOrderByDesc(String tag) {
		return worksMapper.selectRecentlyPopularOrderByDesc(tag);
	}
}
