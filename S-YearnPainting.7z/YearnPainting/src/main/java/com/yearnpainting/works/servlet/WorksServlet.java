package com.yearnpainting.works.servlet;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import com.yearnpainting.test.entity.Test;
import com.yearnpainting.test.mapper.TestMapper;
import com.yearnpainting.user.entity.User;
import com.yearnpainting.works.entity.Works;


public interface WorksServlet {

	boolean uploadUserWorks(String filePath,String fileTag,String fileDescription,User user,Date createTime);
	
	public ResponseEntity<byte[]> getCover(String coverName) throws Exception;
	
	List<Works> selectUserWorks(String userId,String start,String number);
	
	Integer updateWorks(Works works);
	
	Integer deleteWorks(Works works);
	
	public Map selectUserWorksByUserId(Map userMap,String userId);
	
	public List<Works> selectCreateTimeOrderByDesc(String tag);
	
	public List<Works> selectFollowContent(String tag,String userId);
	
	public List<Works> selectOpWorks(Works works);
	
	/**
	 * 人气内容查询
	 * @param tag
	 * @return
	 */
	List<Works> selectPopularityContentOrderByDesc(String tag);
	
	/**
	 * 近期热门查询
	 * @param tag
	 * @return
	 */
	List<Works> selectRecentlyPopularOrderByDesc(String tag);
}
