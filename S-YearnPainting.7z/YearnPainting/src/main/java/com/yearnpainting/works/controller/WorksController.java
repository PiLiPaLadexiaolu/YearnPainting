package com.yearnpainting.works.controller;

import java.io.File;
import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.json.GsonBuilderUtils;
import org.springframework.util.FileCopyUtils;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.yearnpainting.system.annotatin.CheckToken;
import com.yearnpainting.system.utils.JWTUtil;
import com.yearnpainting.user.entity.User;
import com.yearnpainting.user.servlet.UserServlet;
import com.yearnpainting.utils.DateUtil;
import com.yearnpainting.utils.ResultUtil;
import com.yearnpainting.works.entity.Works;
import com.yearnpainting.works.servlet.WorksServlet;

import lombok.extern.slf4j.Slf4j;

@Slf4j
@RestController
@RequestMapping("works")
public class WorksController {

	@Autowired
	UserServlet userServlet;

	@Value("${file-upload.upload-path}")
	public String uploadPath;

	private final static String TOKEN_KEY = "my_secret";

	@Autowired
	WorksServlet worksServlet;

	@CheckToken
	@CrossOrigin
	@PostMapping(value = "/uploadFile")
	public ResultUtil<?> fileUpload(HttpServletRequest request) {
		// 将当前上下文初始化给 CommonsMutipartResolver （多部分解析器）
		CommonsMultipartResolver multipartResolver = new CommonsMultipartResolver(
				request.getSession().getServletContext());
		// 返回值与和insert参数
		HashMap<String, Object> map = new HashMap<String, Object>();
		// 检查form中是否有enctype="multipart/form-data"
		if (multipartResolver.isMultipart(request)) {
			// 将request变成多部分request
			MultipartHttpServletRequest multiRequest = (MultipartHttpServletRequest) request;
			// 获取multiRequest 中所有的文件名
			Iterator<String> iter = multiRequest.getFileNames();
			while (iter.hasNext()) {
				// 一次遍历所有文件
				MultipartFile file = multiRequest.getFile(iter.next().toString());
				// 检查是否有上传文件的路径如果不存在则创建
				File path = new File(uploadPath);
				if (!path.exists()) {
					// 创建文件根目录
					path.mkdirs();
				}
				// 创建文件上传时间
				Date date = new Date();
				// 创建复制文件
				File copyFile = new File(uploadPath + File.separator + DateUtil.dateToTimeNumber(date) + "_"
						+ file.getOriginalFilename());
				// 接收文件标签
				String fileTag = multiRequest.getParameter("fileTag");
				// 接收文件描述
				String fileDescription = multiRequest.getParameter("fileDescription");
				// 接收token
				String token = request.getHeader("token");
				// 获取当前登录用户信息
				User user = JWTUtil.parsingToken(token, TOKEN_KEY);
				if (file != null) {
					try {
						// 将文件复制
						FileCopyUtils.copy(file.getBytes(), copyFile);
						worksServlet.uploadUserWorks(copyFile.getAbsolutePath(), fileTag, fileDescription, user, date);
					} catch (IOException e) {
						e.printStackTrace();
						ResultUtil.FAILURE();
					}
				}
			}
		}
		return ResultUtil.SUCCESS();
	}

	/**
	 * 获取资源封面
	 */
	@RequestMapping(value = "/getWorksImg", method = RequestMethod.GET)
	public ResponseEntity<byte[]> getWorksImg(HttpServletResponse response, HttpServletRequest request)
			throws IOException {
		String fileName = request.getParameter("fileName");
		try {
			return worksServlet.getCover(fileName);
		} catch (Exception e) {
			e.printStackTrace();
			response.setStatus(404);
			return null;
		}
	}

	/**
	 * 获取当前用户全部作品
	 */
	@CheckToken
	@RequestMapping(value = "/getUserWorks", method = RequestMethod.GET)
	public ResultUtil<?> getUserWorks(HttpServletResponse response, HttpServletRequest request) throws IOException {
		// 接收token
		String token = request.getHeader("token");
		// 获取当前登录用户信息
		User user = JWTUtil.parsingToken(token, TOKEN_KEY);
		try {
			List<Works> works = worksServlet.selectUserWorks(user.getId(), null, null);
			return ResultUtil.SUCCESS(works);
		} catch (Exception e) {
			return ResultUtil.FAILURE();
		}
	}

	@CheckToken
	@PutMapping("editWorks")
	public ResultUtil<?> editWorksInfo(@RequestBody Works works, HttpServletRequest request,
			HttpServletResponse response) {
		// @RequestBody 注解是为了接受前端传过来的JSON字符串
		String token = request.getHeader("token");
		User user = JWTUtil.parsingToken(token, TOKEN_KEY);
		works.setUserId(user.getId());
		StringBuffer tags = new StringBuffer();
		for (int i = 0; i < works.getFileTags().length; i++) {
			if (i != works.getFileTags().length - 1) {
				tags.append(works.getFileTags()[i] + ",");
			} else {
				tags.append(works.getFileTags()[i]);
			}
		}
		works.setFileTag(tags.toString());
		int result = worksServlet.updateWorks(works);
		if (result > 0) {
			return ResultUtil.SUCCESS();
		}
		return ResultUtil.FAILURE();
	}

	@CheckToken
	@DeleteMapping("deleteWorks")
	public ResultUtil<?> deleteWorksInfo(@RequestBody Works works, HttpServletRequest request,
			HttpServletResponse response) {
		// @RequestBody 注解是为了接受前端传过来的JSON字符串
		String token = request.getHeader("token");
		User user = JWTUtil.parsingToken(token, TOKEN_KEY);
		works.setUserId(user.getId());
		int result = worksServlet.deleteWorks(works);
		if (result > 0) {
			return ResultUtil.SUCCESS();
		}
		return ResultUtil.FAILURE();
	}

	@CheckToken
	@GetMapping("getOtherUserWorks")
	public ResultUtil<?> getOtherUserWorks(String id, HttpServletRequest request, HttpServletResponse response) {
		// @RequestBody 注解是为了接受前端传过来的JSON字符串
		String token = request.getHeader("token");
		User user = JWTUtil.parsingToken(token, TOKEN_KEY);
		Map map = new HashMap<>();
		map.put("userId", user.getId());
		Map result = worksServlet.selectUserWorksByUserId(map,id);
		return ResultUtil.SUCCESS(result);

	}
	
	/**
	 * 作品模块-最新推荐
	 * @param tag
	 * @param request
	 * @param response
	 * @return
	 */
	@CheckToken
	@GetMapping("createTimeOrderByDesc")
	public ResultUtil<?> createTimeOrderByDesc(String tag, HttpServletRequest request, HttpServletResponse response) {
		// @RequestBody 注解是为了接受前端传过来的JSON字符串
		String token = request.getHeader("token");
		User user = JWTUtil.parsingToken(token, TOKEN_KEY);
		Map map = new HashMap<>();
		map.put("userId", user.getId());
		List<Works> works = worksServlet.selectCreateTimeOrderByDesc(tag);
		return ResultUtil.SUCCESS(works);
	}

	/**
	 * 作品模块-人气内容
	 * @param tag
	 * @param request
	 * @param response
	 * @return
	 */
	@CheckToken
	@GetMapping("popularityContent")
	public ResultUtil<?> popularityContent(String tag, HttpServletRequest request, HttpServletResponse response) {
		// @RequestBody 注解是为了接受前端传过来的JSON字符串
		String token = request.getHeader("token");
		User user = JWTUtil.parsingToken(token, TOKEN_KEY);
		Map map = new HashMap<>();
		map.put("userId", user.getId());
		List<Works> works = worksServlet.selectPopularityContentOrderByDesc(tag);
		return ResultUtil.SUCCESS(works);
	}
	
	/**
	 * 作品模块-近期热门
	 * @param tag
	 * @param request
	 * @param response
	 * @return
	 */
	@CheckToken
	@GetMapping("recentlyPopular")
	public ResultUtil<?> recentlyPopular(String tag, HttpServletRequest request, HttpServletResponse response) {
		// @RequestBody 注解是为了接受前端传过来的JSON字符串
		String token = request.getHeader("token");
		User user = JWTUtil.parsingToken(token, TOKEN_KEY);
		Map map = new HashMap<>();
		map.put("userId", user.getId());
		List<Works> works = worksServlet.selectRecentlyPopularOrderByDesc(tag);
		return ResultUtil.SUCCESS(works);
	}
	
	/**
	 * 作品模块-关注内容
	 * @param tag
	 * @param request
	 * @param response
	 * @return
	 */
	@CheckToken
	@GetMapping("followContent")
	public ResultUtil<?> followContent(String tag, HttpServletRequest request, HttpServletResponse response) {
		// @RequestBody 注解是为了接受前端传过来的JSON字符串
		String token = request.getHeader("token");
		User user = JWTUtil.parsingToken(token, TOKEN_KEY);
		Map map = new HashMap<>();
		map.put("userId", user.getId());
		List<Works> works = worksServlet.selectFollowContent(tag, user.getId());
		return ResultUtil.SUCCESS(works);
	}
	
	/**
	 * 获取全部作品
	 */
	@CheckToken
	@RequestMapping(value = "/getOpWorks", method = RequestMethod.GET)
	public ResultUtil<?> getOpWorks(Works work,HttpServletResponse response, HttpServletRequest request) throws IOException {
		// 接收token
		String token = request.getHeader("token");
		// 获取当前登录用户信息
		User user = JWTUtil.parsingToken(token, TOKEN_KEY);
		try {
			List<Works> works = worksServlet.selectOpWorks(work);
			return ResultUtil.SUCCESS(works);
		} catch (Exception e) {
			return ResultUtil.FAILURE();
		}
	}
	
}
