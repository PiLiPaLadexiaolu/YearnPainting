package com.yearnpainting.works.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.yearnpainting.test.entity.Test;
import com.yearnpainting.user.entity.User;
import com.yearnpainting.works.entity.Works;

@Mapper
public interface WorksMapper {
	/**
	 * 添加作品
	 * @param works
	 * @return
	 */
	Integer insertWorks(Works works);
	
	@Select("SELECT * FROM user_works WHERE user_id = #{userId} ORDER BY create_time DESC")
	List<Works> selectUserWorks(String userId,String start,String number);
	
	@Update("UPDATE user_works SET file_description = #{fileDescription},file_tag = #{fileTag} WHERE  id = #{id} AND user_id = #{userId}")
	Integer updateWorks(Works works);
	
	@Delete("DELETE FROM user_works WHERE id = #{id} AND user_id = #{userId}")
	Integer deleteWorks(Works works);
	
	/**
	 * 根据用户ID查询最新的三条作品数据
	 * @param userId
	 * @param start
	 * @param number
	 * @return
	 */
	@Select("SELECT * FROM user_works WHERE user_id = #{userId} ORDER BY create_time DESC LIMIT 3")
	List<Works> selectUserWorksById(String userId);
	
	/**
	 * 根据用户ID查询作品数据
	 * @param userId
	 * @param start
	 * @param number
	 * @return
	 */
	@Select("SELECT * FROM user_works WHERE user_id = #{userId} ORDER BY create_time DESC")
	List<Works> selectUserWorksByUserId(String userId);
	
	/**
	 * 最新推荐查询
	 * @param tag
	 * @return
	 */
	List<Works> selectCreateTimeOrderByDesc(String tag);
	
	/**
	 * 关注内容查询
	 * @param tag
	 * @param userId
	 * @return
	 */
	List<Works> selectFollowContent(String tag,String userId);
	
	/**
	 * 人气内容查询
	 * @param tag
	 * @return
	 */
	List<Works> selectPopularityContentOrderByDesc(String tag);
	
	/**
	 * 近期热门查询
	 * @param tag
	 * @return
	 */
	List<Works> selectRecentlyPopularOrderByDesc(String tag);
	
	List<Works> selectOpWorks(Works works);
	
	@Update("UPDATE user_works SET `check_number` = `check_number`+1 WHERE file_name = #{filename}")
	Integer updateCheckNumber(String filename);
}
