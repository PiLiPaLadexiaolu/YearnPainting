package com.yearnpainting.release.servlet;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;

import com.yearnpainting.planning.entity.Planning;
import com.yearnpainting.release.entity.Release;
import com.yearnpainting.release.entity.ReleaseVo;
import com.yearnpainting.test.entity.Test;
import com.yearnpainting.test.mapper.TestMapper;
import com.yearnpainting.user.entity.User;
import com.yearnpainting.works.entity.Works;


public interface ReleaseServlet {

	Integer createOrientationRelease(Release release);
	
	Integer createAllRelease(Release release);
	
	List<ReleaseVo> queryPlanningByInviteMe(ReleaseVo releaseVo);
	
	Integer updateRelease(Release release);
}
