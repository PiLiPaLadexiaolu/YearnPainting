package com.yearnpainting.release.mapper;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.yearnpainting.planning.entity.Planning;
import com.yearnpainting.release.entity.Release;
import com.yearnpainting.release.entity.ReleaseVo;
import com.yearnpainting.test.entity.Test;
import com.yearnpainting.user.entity.User;
import com.yearnpainting.works.entity.Works;

@Mapper
public interface ReleaseMapper {
	
	@Insert("INSERT INTO `release` (id, planning_id, release_type, invite_people, accept_users, create_time) VALUES (#{id}, #{planningId}, #{releaseType}, #{invitePeople}, #{acceptUsers}, #{createTime})")
	Integer insertRelease(Release release);
	
	List<ReleaseVo> queryPlanningByInviteMe(ReleaseVo releaseVo);
	
	@Update("UPDATE `release` SET `feedback`=#{feedback} WHERE  `id`=#{id}")
	Integer updateRelease(Release release);
}
