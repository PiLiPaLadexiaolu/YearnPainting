package com.yearnpainting.release.entity;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.fasterxml.jackson.annotation.JsonFormat;

import lombok.Data;

@Data
public class Release {

	private String id;
	private String planningId;
	private String releaseType;
	private String invitePeople;
	private String acceptUsers;
	@JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy年MM月dd HH:mm:ss", timezone = "GMT+8")
	@DateTimeFormat(pattern = "yyyy年MM月dd HH:mm:ss")
	private Date createTime;

}
