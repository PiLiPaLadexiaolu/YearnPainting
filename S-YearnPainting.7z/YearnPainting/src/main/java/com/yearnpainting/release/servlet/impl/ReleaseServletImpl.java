package com.yearnpainting.release.servlet.impl;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.yearnpainting.test.entity.Test;
import com.yearnpainting.test.mapper.TestMapper;
import com.yearnpainting.user.entity.User;
import com.yearnpainting.user.mapper.UserMapper;
import com.yearnpainting.user.servlet.UserServlet;
import com.yearnpainting.utils.UUIDUtil;
import com.yearnpainting.works.entity.Works;
import com.yearnpainting.works.mapper.WorksMapper;
import com.yearnpainting.attention.mapper.AttentionMapper;
import com.yearnpainting.planning.entity.Planning;
import com.yearnpainting.release.entity.Release;
import com.yearnpainting.release.entity.ReleaseVo;
import com.yearnpainting.release.mapper.ReleaseMapper;
import com.yearnpainting.release.servlet.ReleaseServlet;
import com.yearnpainting.works.servlet.WorksServlet;

@Service
public class ReleaseServletImpl implements ReleaseServlet {

	@Value("${file-upload.upload-path}")
	public String uploadPath;

	@Autowired
	WorksMapper worksMapper;

	@Autowired
	UserMapper userMapper;

	@Autowired
	AttentionMapper attentionMapper;

	@Autowired
	ReleaseMapper releaseMapper;

	@Override
	public Integer createOrientationRelease(Release release) {
		// 设置企划ID
		release.setPlanningId(release.getId());
		// 设置ID
		release.setId(UUIDUtil.generate());
		// 定向企划
		release.setReleaseType("0");
		// 创建时间
		release.setCreateTime(new Date());
		return releaseMapper.insertRelease(release);
	}

	@Override
	public Integer createAllRelease(Release release) {
		// 设置企划ID
		release.setPlanningId(release.getId());
		// 设置ID
		release.setId(UUIDUtil.generate());
		// 非定向企划
		release.setReleaseType("1");
		// 创建时间
		release.setCreateTime(new Date());
		return releaseMapper.insertRelease(release);
	}

	@Override
	public List<ReleaseVo> queryPlanningByInviteMe(ReleaseVo releaseVo) {
		return releaseMapper.queryPlanningByInviteMe(releaseVo);
	}

	@Override
	public Integer updateRelease(Release release) {
		return releaseMapper.updateRelease(release);
	}

}
